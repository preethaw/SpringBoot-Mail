# Sending-Emails-using-Spring-Boot-Mail
In this project, I have worked on sending mails via e-mail to other accounts using Spring Boot Mail API.

How to work with this project :

1- Download the entire project, unzip it and import it in Eclipse J2EE.

2- Install all dependencies in the pom.xml file.

3- Fill all necessary properties required in the application.proprties like your Gmail-id and Gmail-app-password.

4- In the Controller file, fill your mail id as the sender and any other mail id as the receiver. You can also edit the Mail subject and content as well as add attachments too.

5- Run the Main file and the mail will be successfully sent to the receiver.
