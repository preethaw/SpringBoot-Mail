package com.frestonanalytics.msl.staffalyze.mail;

import com.frestonanalytics.msl.staffalyze.mail.model.Mail;
import com.frestonanalytics.msl.staffalyze.mail.service.MailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class EmailServiceApplication implements CommandLineRunner
{
	@Autowired
	private MailService mailService;

	public static void main(String[] args) {
		SpringApplication.run(EmailServiceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception
	{
		Mail mail = new Mail();
		mail.setMailFrom("vfxfan@gmail.com");
		mail.setMailTo("preethawarrier@gmail.com");
		mail.setMailSubject("Reset Your Password - Email demo");
		mail.setMailContent("<h3><a href=\"frestonanalytics.com\"> Click here </a>to reset your password on the EMS Application.</h3>");

		mailService.sendEmail(mail);
		
	}

}
