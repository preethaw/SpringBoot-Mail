package com.frestonanalytics.msl.staffalyze.mail.service;

import com.frestonanalytics.msl.staffalyze.mail.model.Mail;

public interface MailService 
{
	public void sendEmail(Mail mail);
}
